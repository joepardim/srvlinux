#!/bin/bash
# Autor: Joás Pardim #Joe
# Site: http://www.climbsoluções.com.br
# Telefone: (62) 3225-6440
# Github: (EM DESENVOLVIMENTO)
# Data de criação: 25/09/2022
# Data de atualização: 25/09/2022
# Versão: 0.10
# Testado e homologado para a versão do Ubuntu Server 20.04.x LTS x64
#DADOS DO SERVIDOR LINUX - CLIMB SOLUÇÕES

# SEMPRE VERIFICAR O SCRIPTI 00-paramentros.sh em caso de instalação
# 
#srvlinux.climb.infra
# 
# Variável do Usuário padrão utilizado no Servidor Ubuntu 
USUARIODEFAULT="climb"

# Variável da Senha padrão utilizado no Servidor Ubuntu 
# OBSERVAÇÃO IMPORTANTE: essa variável será utilizada em outras variáveis 
SENHADEFAULT="climb06"

#
#
# Variável do Nome (Hostname) do Servidor Ubuntu desse curso
NOMESERVER="srvlinux"

#
# Variável do Nome de Domínio do Servidor Ubuntu desse curso
# OBSERVAÇÃO IMPORTANTE: essa variável será utilizada em outras variáveis desse curso
DOMINIOSERVER="climb.infra"

# Variável do Endereço IPv4 principal (padrão) do Servidor Ubuntu 
IPV4SERVER="192.168.1.170"

# Variável do nome do Domínio do Servidor DNS (veja a linha: 64 desse arquivo)
DOMAIN=$DOMINIOSERVER
#
# Variável do nome da Pesquisa Reversa do Servidor de DNS
DOMAINREV="192.168.1.in-addr.arpa"
#
# Variável do endereço IPv4 da Subrede do Servidor de DNS
NETWORK="192.168.1."
#
# Variável de instalação do serviço de rede Bind DNS Server
DNSINSTALL="bind9 bind9utils bind9-doc dnsutils net-tools"

# Acesso remoto utilizando o GNU/Linux ou Microsoft Windows
#
# Linux Mint Terminal: Ctrl+Alt+T
 	ssh climb@192.168.1.170
	ssh climb@ssh.climb.infra
#
# Windows Powershell: Menu, Powershell 
	ssh climb@192.168.1.170
	ssh climb@ssh.climb.infra